# Audit

## Audited Actions

| Action | Actor | Target | Before | After | Timestamp | Reason Required | Request/Trace ID | Retention |
|---|---|---|---|---|---|---|---|---|

## Sensitive Action Coverage

| Sensitive Action | Audit Event Name | Before/After Captured? | Queryable? | Owner |
|---|---|---|---|---|

## Retention Policy

| Data Type | Retention Period | Storage | Access Control |
|---|---|---|---|

## Audit Query Requirements

| Question | Required Fields | Consumer |
|---|---|---|

## Open Audit Risks

| Risk | Impact | Owner | Blocks Release? |
|---|---|---|---|
