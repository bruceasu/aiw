# Permissions

## Roles

| Role | Description | Default Access | Owner |
|---|---|---|---|

## Permission Matrix

| Action | Ops | Customer Support | Risk | Finance | Audit | Admin |
|---|---|---|---|---|---|---|

## Action Types

| Action | View | Export | Edit | Approve | Sensitive? | Audit Required? |
|---|---|---|---|---|---|---|

## Field-Level Restrictions

| Field | Classification | Masking Rule | Allowed Roles |
|---|---|---|---|

## Data Scope Rules

| Role | Data Scope | Restriction | Notes |
|---|---|---|---|

## Open Permission Risks

| Risk | Impact | Owner | Blocks Release? |
|---|---|---|---|
