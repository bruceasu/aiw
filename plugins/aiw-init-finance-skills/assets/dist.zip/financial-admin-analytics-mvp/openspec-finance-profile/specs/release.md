# Release

## Decision

GO / GO WITH RISK / NO GO / NOT REVIEWED

## Scope

| Change | Systems Affected | Data Affected | User Impact | Feature Flag? |
|---|---|---|---|---|

## Release Checklist

| Area | Status | Evidence | Risk | Required Action |
|---|---|---|---|---|
| Schema and migration |  |  |  |  |
| Data impact |  |  |  |  |
| Metrics and reporting |  |  |  |  |
| Permissions |  |  |  |  |
| Audit |  |  |  |  |
| Rollback |  |  |  |  |
| Observability |  |  |  |  |
| Operational support |  |  |  |  |

## Rollback Plan

| Layer | Rollback Method | Owner | Verification |
|---|---|---|---|
| Application |  |  |  |
| Schema |  |  |  |
| Data |  |  |  |
| Feature flag |  |  |  |

## Open Release Risks

| Risk | Severity | Owner | Mitigation | Release Blocker? |
|---|---|---|---|---|
