# Financial Admin & Analytics Skills Pack

> MVP v1.1 — decision-centric workflow for financial admin, operations, reporting, risk, finance, and analytics systems.

## 1. Overview

Financial Admin & Analytics Skills Pack is a collection of ChatGPT Skills for reviewing financial product requirements before implementation. It is designed for financial back-office systems, operations platforms, risk dashboards, finance reports, data pipelines, and internal analytics tools.

The pack is not an AI coding workflow. Its purpose is to improve product and engineering decisions before coding starts.

It focuses on:

- business value
- decision flow
- metrics governance
- data correctness
- permissions
- auditability
- release risk
- operational readiness
- maintainability

The core idea is:

```text
Do not start from "build a page", "add a button", or "make a report".
Start from who uses it, what they see, what decision they make, what action they take, and what risk is reduced.
```

## 2. Package Contents

```text
financial-admin-analytics-mvp/
├── README.md
├── skills/
│   ├── office-hours-finance/
│   ├── business-review/
│   ├── metrics-review/
│   ├── eng-review-finance/
│   ├── release-review/
│   └── autoplan-finance/
├── openspec-finance-profile/
│   └── specs/
│       ├── requirements.md
│       ├── design.md
│       ├── tasks.md
│       ├── metrics.md
│       ├── permissions.md
│       ├── audit.md
│       └── release.md
└── dist/
    ├── office-hours-finance/skill.zip
    ├── business-review/skill.zip
    ├── metrics-review/skill.zip
    ├── eng-review-finance/skill.zip
    ├── release-review/skill.zip
    └── autoplan-finance/skill.zip
```

## 3. Skills Included

### 3.1 office-hours-finance

**Purpose:** Requirement discovery and scope reduction.

Use this Skill when a request is still vague, feature-centric, or not yet tied to a business decision.

Typical inputs:

```text
我们想做一个客户资产查询页面。
风控想看一个风险 dashboard。
运营需要一个新的报表。
客服需要一个后台按钮。
```

What it does:

- identifies the real problem
- maps the decision flow
- identifies stakeholders
- separates Must Have / Should Have / Nice To Have
- lists unknowns
- recommends whether to continue, reduce scope, validate manually, or hold

Key gate:

```text
If there is no clear decision or operational action, recommend HOLD or manual validation first.
```

Output:

```text
Problem Brief
Decision Flow
Stakeholder Map
Scope Split
Unknowns
Recommendation
```

### 3.2 business-review

**Purpose:** Business value review.

Use this Skill to decide whether a requirement is worth building.

Typical inputs:

```text
这个报表值得做吗？
帮我评估这个后台功能的业务价值。
这个需求应该 approve, reduce 还是 hold？
```

Value dimensions:

- increase revenue
- reduce risk
- reduce manual labor cost
- improve decision speed or accuracy
- satisfy regulatory, audit, or compliance requirements
- improve customer experience

Decision output:

```text
APPROVE / REDUCE / HOLD
```

Default rule:

```text
If no value dimension is met, default to HOLD.
```

### 3.3 metrics-review

**Purpose:** Metrics governance and data definition.

Use this Skill before implementing dashboards, reports, metrics APIs, data marts, or operational analytics.

Typical inputs:

```text
帮我定义客户资产指标。
这个 dashboard 的指标口径是否合理？
检查这些财务报表指标有没有冲突。
这个 SQL 里的统计口径是否正确？
```

Each metric must define:

- name
- business definition
- formula
- unit
- time dimension
- refresh frequency
- source system
- source table and field mapping
- business owner
- technical owner
- consistency notes
- known limitations
- readiness gate

Financial correctness checks:

- currency
- base reporting currency
- FX source
- FX conversion timestamp
- decimal precision
- rounding mode
- time zone
- business day cut-off
- settlement cycle
- value date
- snapshot vs ledger transaction semantics
- deduplication
- inclusion / exclusion rules

Readiness output:

```text
READY / INCOMPLETE / CONFLICT
```

Core principle:

```text
Do not only ask how to query the data. First define what the number means.
```

### 3.4 eng-review-finance

**Purpose:** Architecture review before implementation.

Use this Skill when the requirement has enough business clarity and needs a technical design review.

Typical inputs:

```text
帮我设计这个金融后台功能。
审查一下这个数据平台方案。
这个 dashboard 的技术方案是否完整？
我们要从交易系统同步数据到报表系统，怎么设计？
```

Review areas:

- system boundary
- module responsibilities
- dependencies
- data flow
- permissions
- auditability
- failure modes
- observability
- testing strategy

Canonical data flow:

```text
Source -> ETL/streaming -> warehouse/datamart -> API -> dashboard/admin UI
```

Permission review:

- view permission
- export permission
- edit permission
- approval permission
- field-level permission
- data-scope permission

Auditability review:

- actor
- timestamp
- action
- before value
- after value
- reason
- request ID or trace ID
- retention policy

Key gates:

```text
If metrics are undefined, route to metrics-review first.
If permissions are undefined, do not approve the architecture.
If audit requirements are absent for sensitive actions, mark the design incomplete.
```

### 3.5 release-review

**Purpose:** Release readiness review and launch gate.

Use this Skill before releasing financial admin, reporting, risk, finance, analytics, dashboard, permission, schema, or data-pipeline changes.

Typical inputs:

```text
这个版本能上线吗？
帮我做 release review。
这个数据库迁移有没有风险？
这个报表改动上线前需要检查什么？
```

Review areas:

- release scope
- affected systems
- schema changes
- migration risk
- data impact
- metrics and reporting impact
- permission impact
- audit impact
- rollback strategy
- feature flag strategy
- observability
- operational support

Decision output:

```text
GO / GO WITH RISK / NO GO
```

NO GO conditions include:

- rollback plan missing
- permission impact unknown
- audit impact missing for sensitive actions
- migration verification missing
- monitoring missing for high-risk changes
- data reconciliation missing
- unresolved metric definition conflicts

### 3.6 autoplan-finance

**Purpose:** Planning orchestrator.

Use this Skill to combine the planning flow into a complete `PLAN.md`.

Workflow:

```text
office-hours-finance
-> business-review
-> metrics-review
-> eng-review-finance
-> release-review
-> PLAN.md
```

Typical inputs:

```text
帮我为这个金融后台需求生成 PLAN.md。
把这个客户资产 dashboard 需求整理成完整计划。
根据下面的信息生成一个可评审的产品和技术计划。
```

Output structure:

```text
PLAN.md
├── Status
├── Problem
├── Stakeholders
├── Business Value
├── Scope
├── Metrics
├── Data Definition
├── Architecture
├── Permissions
├── Audit Requirements
├── Testing Strategy
├── Release Readiness
├── Risks
├── Milestones
└── Open Questions
```

Hard restrictions:

```text
Do not write code.
Do not modify repository files.
Do not create pull requests.
Do not invent missing business rules, data sources, permissions, or audit requirements.
```

## 4. Recommended Workflow

### 4.1 Full Planning Flow

Use this flow for a new financial admin or analytics requirement:

```text
1. office-hours-finance
   Clarify problem, stakeholders, decision flow, scope, and unknowns.

2. business-review
   Decide whether the request should be APPROVE, REDUCE, or HOLD.

3. metrics-review
   Define metric names, formulas, source fields, owners, and consistency risks.

4. eng-review-finance
   Review architecture, data flow, permissions, auditability, failure modes, and tests.

5. release-review
   Review schema, data, metrics, permissions, audit, rollback, monitoring, and launch risk.

6. autoplan-finance
   Generate the final PLAN.md.
```

### 4.2 Fast Path

Use this when the requirement is small but still financial or operationally sensitive:

```text
office-hours-finance -> metrics-review -> eng-review-finance -> release-review
```

### 4.3 Metrics-First Flow

Use this when the main risk is reporting or dashboard correctness:

```text
metrics-review -> eng-review-finance -> release-review
```

### 4.4 Release-Only Flow

Use this when implementation is already complete and the team needs a launch decision:

```text
release-review
```

## 5. Use Cases

### 5.1 Financial Admin Platform

Examples:

- customer asset inquiry
- account status management
- deposit / withdrawal operations
- manual adjustment workflow
- internal approval dashboard
- customer support investigation screen

Recommended Skills:

```text
office-hours-finance
business-review
metrics-review
eng-review-finance
release-review
autoplan-finance
```

### 5.2 Operations Platform

Examples:

- exception handling queue
- investigation workflow
- operational task assignment
- manual reconciliation process
- customer case review panel

Recommended Skills:

```text
office-hours-finance
business-review
eng-review-finance
release-review
```

### 5.3 Risk Dashboard

Examples:

- customer exposure dashboard
- abnormal activity monitoring
- margin risk view
- concentration risk report
- liquidity risk indicator

Recommended Skills:

```text
office-hours-finance
metrics-review
eng-review-finance
release-review
```

### 5.4 Finance Reporting

Examples:

- daily balance report
- revenue report
- settlement report
- reconciliation report
- audit export

Recommended Skills:

```text
metrics-review
eng-review-finance
release-review
```

### 5.5 Data Pipeline / Dashboard Change

Examples:

- new ETL job
- data mart redesign
- dashboard refresh logic change
- historical backfill
- metric formula change

Recommended Skills:

```text
metrics-review
eng-review-finance
release-review
```

## 6. OpenSpec Finance Profile

The pack includes an OpenSpec-compatible finance profile:

```text
openspec-finance-profile/specs/
├── requirements.md
├── design.md
├── tasks.md
├── metrics.md
├── permissions.md
├── audit.md
└── release.md
```

### 6.1 requirements.md

Captures the product requirement:

- problem
- current workaround
- decision flow
- stakeholders
- business value
- scope
- unknowns

Most important table:

```markdown
| Actor | Situation | Sees | Decides | Acts | Downstream Impact |
|---|---|---|---|---|---|
```

### 6.2 metrics.md

Captures metrics governance:

- metric registry
- source mapping
- financial correctness
- consistency review
- open issues

Use this file to prevent metric ambiguity and reporting conflicts.

### 6.3 permissions.md

Captures authorization design:

- roles
- permission matrix
- action types
- field-level restrictions
- data-scope rules
- open permission risks

Use this file to avoid relying only on page-level permissions.

### 6.4 audit.md

Captures audit requirements:

- audited actions
- sensitive action coverage
- retention policy
- audit query requirements
- open audit risks

Use this file to ensure sensitive actions can be traced after release.

### 6.5 release.md

Captures launch readiness:

- release decision
- scope
- checklist
- rollback plan
- open release risks

Use this file as the release gate before production deployment.

## 7. Installation Guide

### 7.1 Prerequisites

You need:

- access to ChatGPT Skills
- permission to upload custom Skills in your workspace or personal account
- the extracted `financial-admin-analytics-mvp` package

The package contains multiple Skills. Most Skill upload flows expect one Skill archive at a time. Therefore, upload the individual files from the `dist/` directory, not the whole repository zip.

### 7.2 Download and Extract the Package

Download the package and unzip it locally:

```bash
unzip financial-admin-analytics-mvp-v1.1.zip
cd financial-admin-analytics-mvp
```

After extraction, confirm the individual Skill archives exist:

```bash
ls dist/*/skill.zip
```

Expected output:

```text
dist/office-hours-finance/skill.zip
dist/business-review/skill.zip
dist/metrics-review/skill.zip
dist/eng-review-finance/skill.zip
dist/release-review/skill.zip
dist/autoplan-finance/skill.zip
```

### 7.3 Upload Skills in ChatGPT

1. Open ChatGPT.
2. Go to the Skills library. In many environments this is available at:

   ```text
   /skills
   ```

3. Choose the option to create or upload a Skill.
4. Upload one Skill archive at a time.
5. Upload these files:

   ```text
   dist/office-hours-finance/skill.zip
   dist/business-review/skill.zip
   dist/metrics-review/skill.zip
   dist/eng-review-finance/skill.zip
   dist/release-review/skill.zip
   dist/autoplan-finance/skill.zip
   ```

6. Confirm each Skill appears in your Skill library.

Recommended upload order:

```text
1. office-hours-finance
2. business-review
3. metrics-review
4. eng-review-finance
5. release-review
6. autoplan-finance
```

The order is not technically required, but it matches the intended workflow.

### 7.4 Verify Installation

After installation, test each Skill with a short prompt.

#### office-hours-finance

```text
帮我澄清一个金融后台需求：运营想新增一个客户资产查询页面。
```

Expected behavior:

- asks or structures the problem
- maps decision flow
- separates scope
- lists unknowns
- does not start coding

#### business-review

```text
帮我判断这个客户资产查询页面是否值得做，输出 APPROVE / REDUCE / HOLD。
```

Expected behavior:

- evaluates value dimensions
- challenges scope
- gives a decision

#### metrics-review

```text
帮我定义客户总资产这个指标，需要覆盖公式、数据源、币种、精度、刷新频率和 Owner。
```

Expected behavior:

- produces a Metrics Spec
- flags missing source fields or undefined business rules

#### eng-review-finance

```text
帮我审查客户资产 dashboard 的技术方案，重点看数据流、权限、审计和失败模式。
```

Expected behavior:

- reviews architecture
- refuses to approve if metrics, permissions, or audit requirements are missing

#### release-review

```text
这个客户资产 dashboard 准备上线，帮我做 release review，输出 GO / GO WITH RISK / NO GO。
```

Expected behavior:

- checks schema, data, metrics, permissions, audit, rollback, and monitoring
- produces a release decision

#### autoplan-finance

```text
根据下面的需求，生成完整 PLAN.md。需求：运营需要客户资产 dashboard，用于发现异常资产变动并发起调查。
```

Expected behavior:

- generates a structured plan
- includes decision flow, metrics, permissions, audit, testing, risks, and release readiness
- does not write code

## 8. Optional: Install the OpenSpec Finance Profile

The OpenSpec Finance Profile is not uploaded as a ChatGPT Skill. It is a project template that can be copied into your product or engineering repository.

Recommended location:

```text
<your-project>/specs/
```

Copy files:

```bash
cp -R openspec-finance-profile/specs <your-project>/specs
```

Then maintain these documents during planning and implementation:

```text
specs/requirements.md
specs/design.md
specs/tasks.md
specs/metrics.md
specs/permissions.md
specs/audit.md
specs/release.md
```

Recommended review order:

```text
requirements.md -> metrics.md -> permissions.md -> audit.md -> design.md -> release.md -> tasks.md
```

## 9. Optional: Validate OpenSpec Finance Documents

The `autoplan-finance` Skill includes a lightweight validator script.

Run it against a specs directory:

```bash
python skills/autoplan-finance/scripts/validate_openspec_finance.py openspec-finance-profile/specs
```

Use this as a basic completeness check. It does not replace human review or domain review.

Typical validation targets:

- required files exist
- key finance sections are present
- metrics, permissions, audit, and release documents are not missing entirely

## 10. Example End-to-End Prompt

```text
我需要为一个金融后台需求生成完整 PLAN.md。

背景：运营团队需要一个客户资产 dashboard，用于发现客户资产异常波动。

目标：运营发现异常后，可以发起调查，并把问题转给风控或客服。

请按 Financial Admin & Analytics Skills Pack 的流程处理：
1. 先做 office-hours-finance，明确 problem、stakeholders、decision flow、scope、unknowns。
2. 再做 business-review，判断 APPROVE / REDUCE / HOLD。
3. 再做 metrics-review，定义核心指标和数据口径。
4. 再做 eng-review-finance，审查数据流、权限、审计、失败模式和测试策略。
5. 最后做 release-review，给出 GO / GO WITH RISK / NO GO 条件。
6. 输出最终 PLAN.md。

不要写代码，不要创建 PR，不要假设未定义的数据源和权限规则。
```

## 11. Governance Gates

The Skill Pack uses explicit gates to prevent premature implementation.

### 11.1 Decision Gate

Blocked when:

- no clear actor
- no clear situation
- no clear signal or data viewed
- no clear judgment
- no clear operational action
- no downstream impact

### 11.2 Business Gate

HOLD when:

- no revenue impact
- no risk reduction
- no labor cost reduction
- no decision efficiency improvement
- no regulatory / audit / compliance requirement
- no customer experience improvement

### 11.3 Metrics Gate

INCOMPLETE when:

- business definition is missing
- formula is missing
- unit is missing
- time dimension is missing
- refresh frequency is missing
- source mapping is missing
- owner is missing
- currency / precision / cut-off / settlement logic is unclear

CONFLICT when:

- metric conflicts with finance reporting
- metric conflicts with risk reporting
- metric conflicts with management reporting
- duplicate or near-duplicate metric already exists

### 11.4 Permission Gate

Blocked when:

- view permission is undefined
- export permission is undefined
- edit permission is undefined
- approval permission is undefined
- field-level restriction is undefined for sensitive fields
- data-scope rule is undefined
- default role access is unclear

### 11.5 Audit Gate

Blocked when sensitive actions do not capture:

- actor
- timestamp
- action
- target
- before value
- after value
- reason
- request ID or trace ID
- retention policy

### 11.6 Release Gate

NO GO when:

- rollback plan is missing
- permission impact is unknown
- audit impact is missing
- migration verification is missing
- data reconciliation is missing
- monitoring or alerting is missing for high-risk changes
- unresolved critical metrics conflict exists

## 12. Recommended Team Usage

### Product Manager

Use:

```text
office-hours-finance
business-review
autoplan-finance
```

Primary responsibility:

- clarify problem
- define decision flow
- control scope
- document business value

### Data Analyst / Data Engineer

Use:

```text
metrics-review
eng-review-finance
release-review
```

Primary responsibility:

- define metrics
- map data sources
- verify financial correctness
- review pipeline and dashboard impact

### Backend Engineer

Use:

```text
eng-review-finance
release-review
```

Primary responsibility:

- design system boundary
- define APIs and data flow
- implement permissions and audit requirements
- prepare rollback and observability

### Risk / Finance / Audit

Use:

```text
metrics-review
release-review
```

Primary responsibility:

- validate reporting definitions
- review sensitive actions
- confirm audit requirements
- confirm release risk

## 13. What This Pack Does Not Do

The MVP v1.1 pack does not automatically:

- connect to production databases
- scan PR diffs
- inspect repository code
- validate SQL correctness with real schemas
- enforce company-specific RBAC rules
- replace compliance or legal review
- generate migration scripts
- deploy releases

It provides structured review workflows, templates, and lightweight validation. Automated repository, SQL, schema, and PR checks should be added in a later toolchain phase.

## 14. Troubleshooting

### Problem: ChatGPT does not seem to use a Skill

Try explicitly naming the desired Skill in your prompt:

```text
Use metrics-review to define this metric...
```

or:

```text
按 release-review 的格式检查这个上线方案。
```

### Problem: Uploading the whole package fails

Upload individual Skill archives instead:

```text
dist/<skill-name>/skill.zip
```

Do not upload the full `financial-admin-analytics-mvp-v1.1.zip` as one Skill because it contains multiple Skills.

### Problem: The answer starts coding too early

Use a stronger prompt:

```text
Do not write code. Use office-hours-finance and eng-review-finance only. Output review findings and gates.
```

### Problem: Metrics output is too generic

Provide or request these fields explicitly:

```text
business definition, formula, unit, time dimension, refresh frequency, source system, table, field, owner, currency, precision, rounding, cut-off, settlement cycle
```

### Problem: Release review gives GO WITH RISK too easily

Ask it to apply strict NO GO rules:

```text
Apply strict financial release gates. If rollback, audit, permissions, monitoring, or reconciliation is missing, output NO GO.
```

## 15. Version Notes

### MVP v1.1

Included Skills:

- office-hours-finance
- business-review
- metrics-review
- eng-review-finance
- release-review
- autoplan-finance

Major features:

- decision-centric requirement review
- business value review
- metrics governance
- permission and auditability review
- release gate review
- OpenSpec Finance Profile
- lightweight OpenSpec validator

Recommended next additions:

- review-finance for code / SQL / PR review
- incident-review for postmortems
- organization-specific RBAC model
- sensitive action registry
- metric registry integration
- PR diff scanner
- SQL and schema validator

## 16. License and Internal Use

This pack is intended as an internal workflow accelerator for financial product, operations, engineering, data, risk, finance, and audit teams.

Before using it in regulated workflows, adapt the templates to your organization-specific policies, regulatory obligations, audit retention rules, data classification standards, and access-control model.
